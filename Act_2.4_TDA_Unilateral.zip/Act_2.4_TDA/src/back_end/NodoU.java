/*
 Equipo #2
 CONTRERAS RODRIGUEZ JANIS ISABEL
 LIRA DOMINGUEZ BRYANT 
 PARRA GONZALEZ DIEGO ALBERTO
 */
package back_end;

/**
 *
 * @author coter
 */
public class NodoU {
    private Avion dato;
    NodoU siguiente;

    public NodoU(Avion dato) {
        this.dato = dato;
        this.siguiente = null; //Todavia no apunta algo
    }

    public Avion getDato() {
        return dato;
    }

    public void setDato(Avion dato) {
        this.dato = dato;
    }

    public NodoU getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoU siguiente) {
        this.siguiente = siguiente;
    }
    
}//Final
