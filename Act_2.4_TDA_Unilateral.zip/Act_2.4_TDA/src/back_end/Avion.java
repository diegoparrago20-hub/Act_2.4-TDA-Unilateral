/*
 Equipo #2
 CONTRERAS RODRIGUEZ JANIS ISABEL
 LIRA DOMINGUEZ BRYANT 
 PARRA GONZALEZ DIEGO ALBERTO
 */
package back_end;
/**
 *
 * @author coter
 */
//Segun eso un "record" es simplemente esta estructura
public record Avion(
    String noMatricula,  // primario
    String estado,
    String rutaImagen,
    String modelo,
    int capacidad ) {
    @Override
    public String toString() {
        return "==========================================\n" +
               "           DETALLES DEL AVIÓN             \n" +
               "==========================================\n" +
               "• Matrícula         : " + noMatricula + "\n" +
               "• Modelo            : " + modelo + "\n" +
               "• Capacidad         : " + capacidad + " pasajeros\n" +
               "• Estado            : " + estado + "\n" +
               //"• Ruta de Imagen    : " + rutaImagen + "\n" +
               "==========================================";
    }
}//Final
