/*
 Equipo #2
 CONTRERAS RODRIGUEZ JANIS ISABEL
 LIRA DOMINGUEZ BRYANT 
 PARRA GONZALEZ DIEGO ALBERTO
 */
package back_end;

/**
 *
 * @author coter
 */
public class TDAListaUnidireccional {
    private NodoU primero;
    private NodoU ultimo;
    private int tamaño;

    public TDAListaUnidireccional() { // Constructor
        this.primero = null;
        this.ultimo = null;
        this.tamaño = 0;
    }
    
// * Operaciones de Inserción (insertar):
    // 1. Insertar al principio:
    public void insertarPrincipio(Avion dato) {
        NodoU nuevo = new NodoU(dato);
        if (isEmpty()) { // osea diferente de null (metodo auxiliar)
            primero = nuevo;
            ultimo = nuevo;
        } else {
            nuevo.setSiguiente(primero);
            primero = nuevo;
        }
        tamaño++;
    }
    // 2. Insertar al final: 
    public void insertarFinal(Avion dato){
        NodoU nuevo = new NodoU(dato);
        if (isEmpty()) {
            primero = nuevo;
            ultimo = nuevo;
        } else {
            ultimo.setSiguiente(nuevo);
            ultimo = nuevo;
        }
        tamaño++;
    }
    // 3. Insertar por posición:
    public void insertarPosicion(Avion dato, int posicion) {
        if (posicion < 0 || posicion > tamaño) {
            throw new IndexOutOfBoundsException("Posición fuera de rango: " + posicion);
        }
        if (posicion == 0) {
            insertarPrincipio(dato);
            return;
        }
        if (posicion == tamaño) {
            insertarFinal(dato);
            return;
        }
        NodoU nuevo = new NodoU(dato);
        NodoU actual = primero;
        for (int i = 0; i < posicion - 1; i++) {
            actual = actual.getSiguiente();
        }
        nuevo.setSiguiente(actual.getSiguiente());
        actual.setSiguiente(nuevo);
        tamaño++;
    }
// * Operaciones de Remoción (remover):
    //1. Remover al principio:
    public Avion removerPrincipio() {
        if (isEmpty()) { // nadota
            return null;
        }
        NodoU removido = primero;
        if (primero == ultimo) {// 1 elemento
            primero = null;
            ultimo = null;
        } else { // muchos más
            primero = primero.getSiguiente();
        }
        tamaño--;
        return removido.getDato();
    }
    //2. Remover al final: 
    public Avion removerFinal() {
        if (isEmpty()) {
            return null;
        }
        NodoU removido = ultimo;
        if (primero == ultimo) { // si hay 1 elemento
            primero = null;
            ultimo = null;
        } else {
            NodoU actual = primero;
            while (actual.getSiguiente() != ultimo) {  // hasta el penúltimo
                actual = actual.getSiguiente();
            }
            actual.setSiguiente(null);
            ultimo = actual;
        }
        tamaño--;
        return removido.getDato();
    }

    //3. Remover por posición: 
    public Avion removerPosicion(int posicion) {
        if (isEmpty()) { // ver si no es null
            return null;
        }
        if (posicion < 0 || posicion >= tamaño) {
            throw new IndexOutOfBoundsException("Posición fuera de rango: " + posicion);
        }
        if (posicion == 0) { // si es el primero el que se va aborrar
            return removerPrincipio();
        }
        if (posicion == tamaño - 1) {// si es el ultimo el que se va aborrar
            return removerFinal();
        }
        NodoU actual = primero;
        for (int i = 0; i < posicion - 1; i++) {// y ps buscarlo donde esta
            actual = actual.getSiguiente();
        }
        NodoU removido = actual.getSiguiente();
        actual.setSiguiente(removido.getSiguiente());
        tamaño--;
        return removido.getDato();
    }
// * Operaciones de Visualización / Muestra (mostrar):
    //1. Mostrar al principio:
    public Avion mostrarPrincipio() {
        if (isEmpty()) {
            return null;
        }
        return primero.getDato();
    }
    //2. Mostrar al final: 
    public Avion mostrarFinal() {
        if (isEmpty()) {
            return null;
        }
        return ultimo.getDato();
    }
    //3. Mostrar por posición:
    public Avion mostrarPosicion(int posicion) {
        if (isEmpty()) {
            return null;
        }
        if (posicion < 0 || posicion >= tamaño) {
            posicion += 1;
            throw new IndexOutOfBoundsException("Posición fuera de rango: " + posicion);
        }
        NodoU actual = primero;
        for (int i = 0; i < posicion; i++) {
            actual = actual.getSiguiente();
        }
        return actual.getDato();
    }
// * Operación de Búsqueda (buscar por valor):
    //1. Buscar por valor 
    public int buscarPorMatricula(String noMatricula) {
        NodoU actual = primero;
        int pos = 0;
        while (actual != null) {
            if (actual.getDato().noMatricula().equalsIgnoreCase(noMatricula)) {
                return pos;   // si se encontro y ps devuelve su posición
            }
            actual = actual.getSiguiente();
            pos++;
        }
        return -1;// no se encontro
    }
// * Operaciones auxiliares:
    //1. Vaciar y verificar estado:    
    public boolean isEmpty(){
        return primero == null;
    }
    public int size(){ // para ver cuantos elementos hay, como en la act anterior
        return tamaño;
    }
    public void vaciar(){
        primero = null;
        ultimo = null;
        tamaño = 0;
    }
}//Final
